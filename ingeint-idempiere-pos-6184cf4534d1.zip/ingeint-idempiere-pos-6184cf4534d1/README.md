# iDempiere WPOS #

Point Of Sales Developed by Yamel Senih (ysenih@erpcya.com) and ERP Consultores y Asociados (http://erpcya.com/es/), for ADempiere 3.9.0 (http://www.adempiere.net/web/guest/inicio). Migrated and adapted by Victor Suarez (victor.suarez.is@gmail.com) to iDempiere ERP Plugin, Together with Alejandro Guerra (aguerra@algeconsultores.com).

This is the WebUI Version. You can see Swing version: https://bitbucket.org/victorsuarez/org.idempiere.pos

You should use it, with my iDempiere Core Fork: https://bitbucket.org/victorsuarez/idempiere_dev, because I have modified some clases from core for to complete adaptation.

Changes by Orlando Curieles (orlando.curieles@ingeint.com ) 

1.- Migrated to iDempiere 5.1 by Orlando Curieles 
2.- Fix Images display on buttons
3.- Change InfoWindow Product to standard
4.- Create 2Pack Form 
5.- Change Business Partner InfoWindow to standard (In Progress)


